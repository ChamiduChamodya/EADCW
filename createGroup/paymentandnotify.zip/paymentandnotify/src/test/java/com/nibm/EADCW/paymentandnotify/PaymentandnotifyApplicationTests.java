package com.nibm.EADCW.paymentandnotify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentandnotifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
